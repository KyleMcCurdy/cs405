// Project Two: Unit tests for STD-004-CPP (SQL Injection prevention)
//
// Vulnerability tested: SQL injection through dynamically generated
// queries. isSafeSqlInput() is a defense-in-depth screen that runs
// before a query is built; it is not a replacement for parameterized
// queries / prepared statements, which remain the primary control.
//
// Six tests below mix positive results (legitimate input is allowed)
// and negative results (injection attempts are rejected):
//   Test1 - Test4: negative results, malicious input is rejected
//   Test5, Test6:  positive results, legitimate input is allowed

#include "pch.h"
#include "SqlSanitizer.h"

// Test 1: Does isSafeSqlInput() reject a classic OR-based tautology?
TEST(SqlSanitizerTest, RejectsClassicTautology) {
    EXPECT_FALSE(isSafeSqlInput("' OR '1'='1"));
}

// Test 2: Does isSafeSqlInput() reject a comment-based login bypass?
TEST(SqlSanitizerTest, RejectsCommentBasedBypass) {
    EXPECT_FALSE(isSafeSqlInput("admin'--"));
}

// Test 3: Does isSafeSqlInput() reject a stacked query with DROP TABLE?
TEST(SqlSanitizerTest, RejectsStackedDropTableQuery) {
    EXPECT_FALSE(isSafeSqlInput("'; DROP TABLE users; --"));
}

// Test 4: Does isSafeSqlInput() reject a UNION-based data exfiltration attempt?
TEST(SqlSanitizerTest, RejectsUnionSelectExfiltration) {
    EXPECT_FALSE(isSafeSqlInput("1 UNION SELECT username, password FROM users"));
}

// Test 5: Does isSafeSqlInput() allow a normal alphanumeric username?
TEST(SqlSanitizerTest, AllowsOrdinaryUsername) {
    EXPECT_TRUE(isSafeSqlInput("jsmith2024"));
}

// Test 6: Does isSafeSqlInput() correctly handle a legitimate name
// containing an apostrophe? (No attack pattern present, so it passes;
// the apostrophe itself is made safe downstream by a parameterized
// prepared statement, not by this filter.)
TEST(SqlSanitizerTest, AllowsLegitimateApostropheName) {
    EXPECT_TRUE(isSafeSqlInput("O'Brien"));
}
