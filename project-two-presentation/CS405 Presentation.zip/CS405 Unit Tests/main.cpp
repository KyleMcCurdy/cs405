// This file is set to "Not Using Precompiled Headers" in its file
// Properties (C/C++ > Precompiled Headers), so it intentionally does
// NOT include pch.h -- it only needs gtest.h.
#include "gtest/gtest.h"

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
