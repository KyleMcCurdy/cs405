#include "SqlSanitizer.h"
#include <regex>
#include <algorithm>
#include <cctype>

namespace {

    // Lowercases a copy of the input so all pattern checks are case-insensitive
    // (an attacker can just as easily write "UnIoN SeLeCt" as "union select").
    std::string toLower(const std::string& input) {
        std::string result = input;
        std::transform(result.begin(), result.end(), result.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return result;
    }

    // Classic tautology patterns: ' OR '1'='1, ' OR 1=1, etc.
    bool containsTautology(const std::string& lowerInput) {
        static const std::regex tautologyPattern(
            R"('\s*or\s*'?\d*'?\s*=\s*'?\d*'?)");
        return std::regex_search(lowerInput, tautologyPattern);
    }

    // Comment markers that truncate the rest of a query: --, #, /*
    bool containsCommentMarker(const std::string& lowerInput) {
        return lowerInput.find("--") != std::string::npos ||
               lowerInput.find("/*") != std::string::npos ||
               lowerInput.find('#') != std::string::npos;
    }

    // Stacked queries: a statement terminator followed by another command.
    bool containsStackedQuery(const std::string& lowerInput) {
        static const std::regex stackedPattern(
            R"(;\s*(drop|delete|insert|update|alter)\s)");
        return std::regex_search(lowerInput, stackedPattern);
    }

    // UNION-based exfiltration: UNION [ALL] SELECT ...
    bool containsUnionSelect(const std::string& lowerInput) {
        static const std::regex unionPattern(
            R"(union\s+(all\s+)?select)");
        return std::regex_search(lowerInput, unionPattern);
    }

} // namespace

bool isSafeSqlInput(const std::string& input) {
    const std::string lowerInput = toLower(input);

    if (containsTautology(lowerInput))   return false;
    if (containsCommentMarker(lowerInput)) return false;
    if (containsStackedQuery(lowerInput)) return false;
    if (containsUnionSelect(lowerInput))  return false;

    return true;
}
