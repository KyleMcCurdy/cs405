#pragma once
#include <string>

// STD-004-CPP: Sanitize Data Used in Dynamically Generated SQL Queries
//
// isSafeSqlInput() screens a string for common SQL injection patterns
// (tautologies, comment markers, stacked queries, and UNION-based
// attacks) before it is used to build a query. This is a defense-in-depth
// check only: the primary control against SQL injection is always a
// parameterized query / prepared statement, which binds user input as
// data rather than executable SQL. This detector exists to catch obvious
// attack patterns early and to flag ambiguous input (e.g., a legitimate
// apostrophe) for safe handling further down the pipeline.
bool isSafeSqlInput(const std::string& input);
