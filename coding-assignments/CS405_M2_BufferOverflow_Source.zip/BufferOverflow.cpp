// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // FIX: account_number stays exactly where it was, directly before the input
  //  variable, as required. The overflow itself is prevented below by changing
  //  HOW we read into user_input, not by moving or resizing account_number.
  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";

  // FIX: std::cin.getline() takes the size of the destination buffer as its
  //  second argument (sizeof(user_input)). Unlike the original std::cin >> user_input,
  //  which has no idea how big user_input is and will happily keep writing bytes
  //  past the end of the array, getline() will never write more than
  //  sizeof(user_input) - 1 characters, always leaving room for the null
  //  terminator. This makes it physically impossible for typed input to spill
  //  into account_number's memory, no matter how many characters are entered.
  std::cin.getline(user_input, sizeof(user_input));

  // FIX: When getline() is handed more characters than the buffer can hold, it
  //  stops safely at the limit but also sets the stream's failbit and leaves the
  //  unread characters sitting in the input buffer. We check for that here so we
  //  can detect the overflow attempt, warn the user, and clean up the stream
  //  instead of silently continuing with a corrupted/partial cin state.
  if (std::cin.fail())
  {
    // Clear the failbit/eofbit so cin is usable again.
    std::cin.clear();

    // Discard everything still waiting in the input buffer up to the next
    // newline, so leftover characters from the oversized entry don't bleed
    // into any future reads.
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    std::cout << "Warning: your entry was too long and was truncated to "
              << (sizeof(user_input) - 1) << " characters to protect the program." << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
