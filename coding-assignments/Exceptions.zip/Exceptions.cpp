// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <string>

// Custom exception class derived from std::exception.
// Overriding what() lets this exception be caught and reported the same
// way as any standard exception, which keeps the error-handling code
// consistent throughout the application.
class CustomException : public std::exception
{
public:
  explicit CustomException(const std::string& message) : message_(message) {}

  // noexcept matches the signature of std::exception::what()
  const char* what() const noexcept override
  {
    return message_.c_str();
  }

private:
  std::string message_;
};

bool do_even_more_custom_application_logic()
{
  // Throw a standard exception to simulate an unexpected failure deep
  // inside the application logic.
  throw std::runtime_error("Exception from do_even_more_custom_application_logic");

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}
void do_custom_application_logic()
{
  // Wrap the call to do_even_more_custom_application_logic() with an
  // exception handler that catches std::exception, displays a message
  // and the exception.what(), then continues processing instead of
  // letting the program crash.
  std::cout << "Running Custom Application Logic." << std::endl;

  try
  {
    if (do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& e)
  {
    std::cout << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
  }

  // Throw a custom exception derived from std::exception and catch it
  // explicitly in main so the caller can decide how to handle it.
  throw CustomException("Custom exception thrown from do_custom_application_logic");

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // Throw a standard C++ exception to deal with divide-by-zero errors.
  // std::overflow_error is part of the standard library and communicates
  // that the requested division cannot produce a valid finite result.
  if (den == 0)
  {
    throw std::overflow_error("Divide by zero exception");
  }

  return (num / den);
}

void do_division() noexcept
{
  // Create an exception handler that captures ONLY the exception type
  // thrown by divide(), so unrelated exceptions are not accidentally
  // swallowed here.
  float numerator = 10.0f;
  float denominator = 0;

  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::overflow_error& e)
  {
    std::cout << "Exception caught in do_division: " << e.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // Create exception handlers that catch (in this order):
  //  1. our custom exception (most specific)
  //  2. std::exception (covers any other standard-derived exception)
  //  3. an uncaught/unknown exception (catch-all safety net)
  // This wraps the whole main function and displays a message to the
  // console instead of letting the application crash to the desktop.
  try
  {
    do_division();
    do_custom_application_logic();
  }
  catch (const CustomException& e)
  {
    std::cout << "Custom exception caught in main: " << e.what() << std::endl;
  }
  catch (const std::exception& e)
  {
    std::cout << "Standard exception caught in main: " << e.what() << std::endl;
  }
  catch (...)
  {
    std::cout << "Unknown exception caught in main." << std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
