// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Kyle McCurdy
// CS 405
// Module One Activity: Numeric Overflow

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <optional>     // std::optional
#include <cmath>        // std::isinf

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
///
/// CHANGE: Now returns std::optional<T> instead of T.
///   - Before each addition, we check if the result would exceed
///     std::numeric_limits<T>::max(). If it would, we return std::nullopt
///     to signal that an overflow was detected and prevented.
///   - For floating-point types, std::numeric_limits<T>::has_infinity is
///     true, so we check isinf() after each step instead, since float math
///     doesn't hard-wrap the way integers do.
///   - If every step completes safely, we return the computed result.
/// </summary>
/// <typeparam name="T">A numeric type that supports basic math</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>std::optional<T> with the result, or std::nullopt on overflow</returns>
template <typename T>
std::optional<T> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // For floating-point types: check for infinity after the addition.
        // Floats do not wrap like integers; they produce infinity on overflow.
        if (std::numeric_limits<T>::has_infinity)
        {
            result += increment;
            if (std::isinf(result))
            {
                // Overflow detected for floating-point type; return nullopt
                return std::nullopt;
            }
        }
        else
        {
            // For integer types: check BEFORE adding to prevent wraparound.
            // If (max - result) < increment, the next addition would overflow.
            if (increment > 0 && result > std::numeric_limits<T>::max() - increment)
            {
                // Overflow would occur; return nullopt without performing the addition
                return std::nullopt;
            }
            result += increment;
        }
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
///
/// CHANGE: Now returns std::optional<T> instead of T.
///   - Before each subtraction, we check if the result would fall below
///     std::numeric_limits<T>::lowest(). If it would, we return std::nullopt
///     to signal that an underflow was detected and prevented.
///   - For floating-point types, we check isinf() after the subtraction
///     since they can go to -infinity rather than wrapping.
///   - If every step completes safely, we return the computed result.
/// </summary>
/// <typeparam name="T">A numeric type that supports basic math</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="decrement">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>std::optional<T> with the result, or std::nullopt on underflow</returns>
template <typename T>
std::optional<T> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // For floating-point types: check for infinity after the subtraction.
        if (std::numeric_limits<T>::has_infinity)
        {
            result -= decrement;
            if (std::isinf(result))
            {
                // Underflow detected for floating-point type; return nullopt
                return std::nullopt;
            }
        }
        else
        {
            // For integer types: check BEFORE subtracting to prevent wraparound.
            // If (result - lowest) < decrement, the next subtraction would underflow.
            if (decrement > 0 && result < std::numeric_limits<T>::lowest() + decrement)
            {
                // Underflow would occur; return nullopt without performing the subtraction
                return std::nullopt;
            }
            result -= decrement;
        }
    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // CHANGE: add_numbers now returns std::optional<T>.
    // We check if the optional has a value. If it does, the operation succeeded
    // and we print the result. If it is empty (nullopt), we report overflow.

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    std::optional<T> result = add_numbers<T>(start, increment, steps);
    if (result.has_value())
    {
        std::cout << +result.value() << std::endl;
    }
    else
    {
        std::cout << "Overflow Detected!" << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);
    if (result.has_value())
    {
        std::cout << +result.value() << std::endl;
    }
    else
    {
        std::cout << "Overflow Detected!" << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // CHANGE: subtract_numbers now returns std::optional<T>.
    // We check if the optional has a value. If it does, the operation succeeded
    // and we print the result. If it is empty (nullopt), we report underflow.

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    std::optional<T> result = subtract_numbers<T>(start, decrement, steps);
    if (result.has_value())
    {
        std::cout << +result.value() << std::endl;
    }
    else
    {
        std::cout << "Underflow Detected!" << std::endl;
    }

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);
    if (result.has_value())
    {
        std::cout << +result.value() << std::endl;
    }
    else
    {
        std::cout << "Underflow Detected!" << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
